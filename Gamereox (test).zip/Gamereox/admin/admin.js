// ==================================================
// GAMEREOX SECURE ADMIN PANEL
// Firebase Authentication + Firestore
// ==================================================


import {
    db,
    auth
} from "../firebase.js";


import {
    collection,
    getDocs,
    deleteDoc,
    doc,
    getDoc,
    setDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";



// ==================================================
// ELEMENTS
// ==================================================

const adminEmail =
    document.getElementById("adminEmail");


const logoutBtn =
    document.getElementById("logoutBtn");


const sidebarLogout =
    document.getElementById("sidebarLogout");


const saveHomepage =
    document.getElementById("saveHomepage");



// ==================================================
// SECURITY STATE
// ==================================================

let adminVerified = false;



// ==================================================
// AUTHENTICATION + ADMIN AUTHORIZATION
// ==================================================

onAuthStateChanged(
    auth,
    async (user) => {

        // ------------------------------------------
        // No logged-in user
        // ------------------------------------------

        if (!user) {

            window.location.replace(
                "login.html"
            );

            return;

        }



        try {

            // --------------------------------------
            // Get admins/{user.uid}
            // --------------------------------------

            const adminRef =
                doc(
                    db,
                    "admins",
                    user.uid
                );


            const adminSnapshot =
                await getDoc(
                    adminRef
                );



            // --------------------------------------
            // Admin document doesn't exist
            // --------------------------------------

            if (!adminSnapshot.exists()) {

                console.warn(
                    "Unauthorized user:",
                    user.uid
                );


                adminVerified =
                    false;


                await signOut(auth);


                window.location.replace(
                    "login.html"
                );


                return;

            }



            // --------------------------------------
            // Read admin data
            // --------------------------------------

            const adminData =
                adminSnapshot.data();



            // --------------------------------------
            // Require role = admin
            // --------------------------------------

            if (
                adminData.role !== "admin"
            ) {

                console.warn(
                    "User is not an admin:",
                    user.uid
                );


                adminVerified =
                    false;


                await signOut(auth);


                window.location.replace(
                    "login.html"
                );


                return;

            }



            // --------------------------------------
            // ADMIN VERIFIED
            // --------------------------------------

            adminVerified =
                true;



            if (adminEmail) {

                adminEmail.textContent =
                    user.email || "Admin";

            }



            // --------------------------------------
            // Load dashboard only after verification
            // --------------------------------------

            await loadDashboard();

            await loadHomepageSettings();

        }


        catch (error) {

            console.error(
                "Admin authorization error:",
                error
            );


            adminVerified =
                false;



            try {

                await signOut(auth);

            }

            catch (logoutError) {

                console.error(
                    "Security logout error:",
                    logoutError
                );

            }


            window.location.replace(
                "login.html"
            );

        }

    }
);



// ==================================================
// ADMIN SECURITY CHECK
// ==================================================

function requireAdmin() {

    if (!adminVerified) {

        throw new Error(
            "Unauthorized admin action."
        );

    }

}



// ==================================================
// LOGOUT
// ==================================================

async function logout() {

    try {

        await signOut(auth);


        window.location.replace(
            "login.html"
        );

    }


    catch (error) {

        console.error(
            "Logout error:",
            error
        );


        alert(
            "Unable to logout."
        );

    }

}



if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        logout
    );

}



if (sidebarLogout) {

    sidebarLogout.addEventListener(
        "click",
        (event) => {

            event.preventDefault();

            logout();

        }
    );

}



// ==================================================
// DASHBOARD
// ==================================================

async function loadDashboard() {

    requireAdmin();


    await loadGames();

    await loadNewsCount();

    await loadDealsCount();

    await loadUpcomingCount();

}



// ==================================================
// LOAD GAMES
// ==================================================

async function loadGames() {

    requireAdmin();


    const gameList =
        document.getElementById(
            "gameList"
        );


    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "games"
                )
            );


        const games =
            snapshot.docs.map(
                (gameDoc) => ({

                    id:
                        gameDoc.id,

                    ...gameDoc.data()

                })
            );



        // ------------------------------------------
        // Total games
        // ------------------------------------------

        const totalGames =
            document.getElementById(
                "totalGames"
            );


        if (totalGames) {

            totalGames.textContent =
                games.length;

        }



        if (!gameList) {

            return;

        }



        gameList.innerHTML =
            "";



        // ------------------------------------------
        // No games
        // ------------------------------------------

        if (!games.length) {

            gameList.innerHTML = `
                <p class="loading">
                    No games added yet.
                </p>
            `;

            return;

        }



        // ------------------------------------------
        // Show first 10 games
        // ------------------------------------------

        games
            .slice(0, 10)
            .forEach(
                (game) => {

                    const item =
                        document.createElement(
                            "div"
                        );


                    item.className =
                        "game-item";



                    const platforms =
                        Array.isArray(
                            game.platforms
                        )
                        ? game.platforms.join(
                            " • "
                        )
                        : "No platform";



                    item.innerHTML = `

                        <h3>
                            ${escapeHTML(
                                game.name ||
                                "Unknown Game"
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                game.description ||
                                "No description"
                            )}
                        </p>

                        <p>
                            🎮 ${escapeHTML(
                                platforms
                            )}
                        </p>

                        <button
                            class="delete-btn"
                            type="button"
                        >
                            Delete
                        </button>

                    `;



                    const deleteButton =
                        item.querySelector(
                            ".delete-btn"
                        );



                    if (deleteButton) {

                        deleteButton.addEventListener(
                            "click",
                            () => {

                                deleteGame(
                                    game.id,
                                    game.name
                                );

                            }
                        );

                    }



                    gameList.appendChild(
                        item
                    );

                }
            );

    }


    catch (error) {

        console.error(
            "Games loading error:",
            error
        );


        if (gameList) {

            gameList.innerHTML = `
                <p class="loading">
                    Failed to load games.
                </p>
            `;

        }

    }

}



// ==================================================
// DELETE GAME
// ==================================================

async function deleteGame(
    id,
    name
) {

    requireAdmin();



    const confirmed =
        confirm(
            `Delete "${name || "this game"}"?`
        );


    if (!confirmed) {

        return;

    }



    try {

        await deleteDoc(
            doc(
                db,
                "games",
                id
            )
        );


        alert(
            "Game deleted successfully."
        );


        await loadDashboard();

    }


    catch (error) {

        console.error(
            "Delete game error:",
            error
        );


        alert(
            "Failed to delete game."
        );

    }

}



// ==================================================
// NEWS COUNT
// ==================================================

async function loadNewsCount() {

    requireAdmin();


    const element =
        document.getElementById(
            "totalNews"
        );


    if (!element) {

        return;

    }



    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "news"
                )
            );


        element.textContent =
            snapshot.size;

    }


    catch (error) {

        console.error(
            "News count error:",
            error
        );


        element.textContent =
            "0";

    }

}



// ==================================================
// DEAL COUNT
// ==================================================

async function loadDealsCount() {

    requireAdmin();


    const element =
        document.getElementById(
            "totalDeals"
        );


    if (!element) {

        return;

    }



    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "deals"
                )
            );


        const today =
            getToday();


        let activeDeals =
            0;



        snapshot.forEach(
            (dealDoc) => {

                const deal =
                    dealDoc.data();


                if (
                    !deal.endDate ||
                    deal.endDate >= today
                ) {

                    activeDeals++;

                }

            }
        );


        element.textContent =
            activeDeals;

    }


    catch (error) {

        console.error(
            "Deal count error:",
            error
        );


        element.textContent =
            "0";

    }

}



// ==================================================
// UPCOMING COUNT
// ==================================================

async function loadUpcomingCount() {

    requireAdmin();


    const element =
        document.getElementById(
            "totalUpcoming"
        );


    if (!element) {

        return;

    }



    try {

        const snapshot =
            await getDocs(
                collection(
                    db,
                    "upcoming"
                )
            );


        const today =
            getToday();


        let upcomingCount =
            0;



        snapshot.forEach(
            (upcomingDoc) => {

                const game =
                    upcomingDoc.data();


                if (
                    !game.releaseDate ||
                    game.releaseDate >= today
                ) {

                    upcomingCount++;

                }

            }
        );


        element.textContent =
            upcomingCount;

    }


    catch (error) {

        console.error(
            "Upcoming count error:",
            error
        );


        element.textContent =
            "0";

    }

}



// ==================================================
// DEFAULT HOMEPAGE SETTINGS
// ==================================================

const defaultHomepageSettings = {

    heroTitle:
        "Gaming updates.\nPlayable games.",


    heroDescription:
        "Gaming news, playable web games, upcoming releases and deals.",


    newsTitle:
        "Latest Gaming News",


    dealsTitle:
        "Today's Deals",


    upcomingTitle:
        "Upcoming Games",


    topRatedTitle:
        "Top Rated",


    platformTitle:
        "Browse by Platform",



    showNews:
        true,


    showDeals:
        true,


    showUpcoming:
        true,


    showTopRated:
        true,


    showPlatforms:
        true,



    newsLimit:
        6,


    dealsLimit:
        6,


    upcomingLimit:
        6,


    topRatedLimit:
        6,


    gamesLimit:
        6

};



// ==================================================
// LOAD HOMEPAGE SETTINGS
// ==================================================

async function loadHomepageSettings() {

    requireAdmin();


    try {

        const homepageRef =
            doc(
                db,
                "settings",
                "homepage"
            );


        const snapshot =
            await getDoc(
                homepageRef
            );



        const settings =
            snapshot.exists()
            ? {
                ...defaultHomepageSettings,
                ...snapshot.data()
            }
            : defaultHomepageSettings;



        // ------------------------------------------
        // TEXT
        // ------------------------------------------

        setValue(
            "heroTitle",
            settings.heroTitle
        );


        setValue(
            "heroDescription",
            settings.heroDescription
        );


        setValue(
            "newsTitle",
            settings.newsTitle
        );


        setValue(
            "dealsTitle",
            settings.dealsTitle
        );


        setValue(
            "upcomingTitle",
            settings.upcomingTitle
        );


        setValue(
            "topRatedTitle",
            settings.topRatedTitle
        );


        setValue(
            "platformTitle",
            settings.platformTitle
        );



        // ------------------------------------------
        // VISIBILITY
        // ------------------------------------------

        setChecked(
            "showNews",
            settings.showNews
        );


        setChecked(
            "showDeals",
            settings.showDeals
        );


        setChecked(
            "showUpcoming",
            settings.showUpcoming
        );


        setChecked(
            "showTopRated",
            settings.showTopRated
        );


        setChecked(
            "showPlatforms",
            settings.showPlatforms
        );



        // ------------------------------------------
        // LIMITS
        // ------------------------------------------

        setNumber(
            "newsLimit",
            settings.newsLimit
        );


        setNumber(
            "dealsLimit",
            settings.dealsLimit
        );


        setNumber(
            "upcomingLimit",
            settings.upcomingLimit
        );


        setNumber(
            "topRatedLimit",
            settings.topRatedLimit
        );


        setNumber(
            "gamesLimit",
            settings.gamesLimit
        );


        console.log(
            "Homepage settings loaded."
        );

    }


    catch (error) {

        console.error(
            "Homepage settings error:",
            error
        );


        showHomepageStatus(
            "Failed to load settings.",
            true
        );

    }

}



// ==================================================
// SAVE BUTTON
// ==================================================

if (saveHomepage) {

    saveHomepage.addEventListener(
        "click",
        saveHomepageSettings
    );

}



// ==================================================
// SAVE HOMEPAGE SETTINGS
// ==================================================

async function saveHomepageSettings() {

    try {

        requireAdmin();

    }


    catch (error) {

        alert(
            "Unauthorized admin action."
        );

        return;

    }



    showHomepageStatus(
        "Saving...",
        false
    );



    // ----------------------------------------------
    // Build settings object
    // ----------------------------------------------

    const settings = {

        heroTitle:
            getValue(
                "heroTitle"
            ),


        heroDescription:
            getValue(
                "heroDescription"
            ),


        newsTitle:
            getValue(
                "newsTitle"
            ),


        dealsTitle:
            getValue(
                "dealsTitle"
            ),


        upcomingTitle:
            getValue(
                "upcomingTitle"
            ),


        topRatedTitle:
            getValue(
                "topRatedTitle"
            ),


        platformTitle:
            getValue(
                "platformTitle"
            ),



        showNews:
            getChecked(
                "showNews"
            ),


        showDeals:
            getChecked(
                "showDeals"
            ),


        showUpcoming:
            getChecked(
                "showUpcoming"
            ),


        showTopRated:
            getChecked(
                "showTopRated"
            ),


        showPlatforms:
            getChecked(
                "showPlatforms"
            ),



        newsLimit:
            getNumber(
                "newsLimit",
                6
            ),


        dealsLimit:
            getNumber(
                "dealsLimit",
                6
            ),


        upcomingLimit:
            getNumber(
                "upcomingLimit",
                6
            ),


        topRatedLimit:
            getNumber(
                "topRatedLimit",
                6
            ),


        gamesLimit:
            getNumber(
                "gamesLimit",
                6
            )

    };



    try {

        await setDoc(
            doc(
                db,
                "settings",
                "homepage"
            ),
            settings,
            {
                merge: true
            }
        );


        showHomepageStatus(
            "✓ Saved successfully.",
            false
        );


        console.log(
            "Homepage settings saved."
        );


        setTimeout(
            () => {

                showHomepageStatus(
                    "",
                    false
                );

            },
            4000
        );

    }


    catch (error) {

        console.error(
            "Save homepage error:",
            error
        );


        showHomepageStatus(
            "✕ Save failed. Check Firestore Rules.",
            true
        );

    }

}



// ==================================================
// HOMEPAGE STATUS
// ==================================================

function showHomepageStatus(
    message,
    isError
) {

    const status =
        document.getElementById(
            "homepageStatus"
        );


    if (!status) {

        return;

    }


    status.textContent =
        message;


    status.style.color =
        isError
        ? "#e53935"
        : "#198754";

}



// ==================================================
// DATE
// ==================================================

function getToday() {

    return new Date()
        .toISOString()
        .split("T")[0];

}



// ==================================================
// GET TEXT
// ==================================================

function getValue(id) {

    const element =
        document.getElementById(
            id
        );


    return element
        ? element.value.trim()
        : "";

}



// ==================================================
// SET TEXT
// ==================================================

function setValue(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.value =
            value ?? "";

    }

}



// ==================================================
// GET NUMBER
// ==================================================

function getNumber(
    id,
    fallback = 6
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return fallback;

    }


    const value =
        parseInt(
            element.value,
            10
        );


    if (
        Number.isNaN(value) ||
        value < 1
    ) {

        return fallback;

    }


    return Math.min(
        value,
        50
    );

}



// ==================================================
// SET NUMBER
// ==================================================

function setNumber(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return;

    }


    const number =
        parseInt(
            value,
            10
        );


    element.value =
        (
            Number.isNaN(number) ||
            number < 1
        )
        ? 6
        : Math.min(
            number,
            50
        );

}



// ==================================================
// GET CHECKBOX
// ==================================================

function getChecked(id) {

    const element =
        document.getElementById(
            id
        );


    return element
        ? element.checked
        : false;

}



// ==================================================
// SET CHECKBOX
// ==================================================

function setChecked(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.checked =
            Boolean(value);

    }

}



// ==================================================
// ESCAPE HTML
// ==================================================

function escapeHTML(value) {

    return String(
        value ?? ""
    )

        .replaceAll(
            "&",
            "&amp;"
        )

        .replaceAll(
            "<",
            "&lt;"
        )

        .replaceAll(
            ">",
            "&gt;"
        )

        .replaceAll(
            '"',
            "&quot;"
        )

        .replaceAll(
            "'",
            "&#039;"
        );

}