// ==================================================
// GAMEREOX ADMIN - ADD GAME
// ==================================================

import { db } from "../firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ==================================================
// SAVE GAME
// ==================================================

window.saveGame = async function () {

    try {

        // ==========================================
        // BASIC INFORMATION
        // ==========================================

        const name =
            document.getElementById("gameName")
                .value
                .trim();

        const slug =
            document.getElementById("slug")
                .value
                .trim()
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, "-")
                .replace(/^-+|-+$/g, "");

        const image =
            document.getElementById("coverImage")
                .value
                .trim();

        const description =
            document.getElementById("description")
                .value
                .trim();


        if (!name) {

            alert("Please enter a game name.");

            return;

        }


        // ==========================================
        // PLATFORMS
        // ==========================================

        const platforms =
            Array.from(
                document.querySelectorAll(
                    ".platform:checked"
                )
            ).map(
                platform => platform.value
            );


        // ==========================================
        // GENRES
        // ==========================================

        const genres =
            Array.from(
                document.querySelectorAll(
                    ".genre:checked"
                )
            ).map(
                genre => genre.value
            );


        // ==========================================
        // GAME DETAILS
        // ==========================================

        const gameDetails =
            Array.from(
                document.querySelectorAll(
                    ".gameDetail:checked"
                )
            ).map(
                detail => detail.value
            );


        // ==========================================
        // SEO
        // ==========================================

        const seoTitle =
            document.getElementById("seoTitle")
                .value
                .trim();

        const seoDescription =
            document.getElementById("seoDescription")
                .value
                .trim();


        // ==========================================
        // CREATE GAME OBJECT
        // ==========================================

        const game = {

            name: name,

            slug: slug || name
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, "-")
                .replace(/^-+|-+$/g, ""),

            image: image,

            description: description,


            developer:
                document.getElementById("developer")
                    .value
                    .trim(),


            publisher:
                document.getElementById("publisher")
                    .value
                    .trim(),


            platforms: platforms,

            genres: genres,


            releaseDate:
                document.getElementById("releaseDate")
                    .value,


            status:
                document.getElementById("status")
                    .value,


            weeklyRelease:
                document.getElementById("weeklyRelease")
                    .checked,


            featured:
                document.getElementById("featured")
                    .checked,


            gameDetails: gameDetails,


            rating:
                document.getElementById("rating")
                    .value,


            gameSize:
                document.getElementById("gameSize")
                    .value
                    .trim(),


            // ======================================
            // SEO
            // ======================================

            seoTitle:
                seoTitle ||
                `${name} - Release Date, Platforms & Details | GameReox`,

            seoDescription:
                seoDescription ||
                description.substring(0, 160),


            // ======================================
            // STORE LINKS
            // ======================================

            stores: {

                xbox:
                    document.getElementById("xboxStore")
                        .value
                        .trim(),

                playstation:
                    document.getElementById("playstationStore")
                        .value
                        .trim(),

                steam:
                    document.getElementById("steamStore")
                        .value
                        .trim(),

                epic:
                    document.getElementById("epicStore")
                        .value
                        .trim(),

                official:
                    document.getElementById("officialWebsite")
                        .value
                        .trim()

            },


            // ======================================
            // YOUTUBE
            // ======================================

            youtube:
                document.getElementById("youtube")
                    .value
                    .trim(),


            // ======================================
            // CREATED TIME
            // ======================================

            createdAt:
                serverTimestamp()

        };


        // ==========================================
        // SAVE TO FIREBASE
        // ==========================================

        await addDoc(
            collection(db, "games"),
            game
        );


        // ==========================================
        // SUCCESS
        // ==========================================

        alert(
            "Game Saved Successfully 🎮"
        );


        window.location.href =
            "admin.html";


    }

    catch (error) {

        console.error(
            "Game save error:",
            error
        );

        alert(
            "Failed to save game. Check the console."
        );

    }

};