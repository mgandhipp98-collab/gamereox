// ==================================================
// GAMEREOX ADMIN SECURITY GUARD
// ==================================================

import { auth } from "../firebase.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";


// ==================================================
// PROTECT ADMIN PAGE
// ==================================================

onAuthStateChanged(auth, (user) => {
  
  if (!user) {
    
    console.warn(
      "GameReox: Unauthorized admin page access."
    );
    
    // Prevent page from remaining accessible
    document.documentElement.style.display = "none";
    
    window.location.replace(
      "index.html"
    );
    
    return;
  }
  
  
  console.log(
    "GameReox: Admin authenticated:",
    user.email
  );
  
});