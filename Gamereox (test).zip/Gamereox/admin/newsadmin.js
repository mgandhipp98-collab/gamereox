let news = JSON.parse(localStorage.getItem("news")) || [];
let newsList = document.getElementById("newsList");

if(news.length === 0){

    newsList.innerHTML = `
        <p>No news has been added yet.</p>
    `;

}else{

    news.forEach(function(item){

        newsList.innerHTML += `

        <div class="news-item">

            <h3>${item.title}</h3>

            <p>📂 ${item.category}</p>

            <small>📅 ${item.publishDate}</small>

            <button onclick="deleteNews('${item.title}')">
                🗑 Delete
            </button>

        </div>

        `;

    });

}

function deleteNews(title){

    let news = JSON.parse(localStorage.getItem("news")) || [];

    news = news.filter(item => item.title !== title);

    localStorage.setItem("news", JSON.stringify(news));

    location.reload();

}