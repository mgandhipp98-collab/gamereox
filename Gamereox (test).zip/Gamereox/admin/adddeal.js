import { db } from "../firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ==================================================
// ELEMENTS
// ==================================================

const gameDeal =
    document.getElementById("gameDeal");

const storeSale =
    document.getElementById("storeSale");

const gameDealSection =
    document.getElementById("gameDealSection");

const storeSaleSection =
    document.getElementById("storeSaleSection");

const originalPrice =
    document.getElementById("originalPrice");

const discountedPrice =
    document.getElementById("discountedPrice");

const discountPreview =
    document.getElementById("discountPreview");

const saveButton =
    document.getElementById("saveButton");

const previewButton =
    document.getElementById("previewButton");


// ==================================================
// DEAL TYPE SWITCH
// ==================================================

gameDeal.addEventListener("change", () => {

    gameDealSection.style.display = "block";

    storeSaleSection.style.display = "none";

});


storeSale.addEventListener("change", () => {

    gameDealSection.style.display = "none";

    storeSaleSection.style.display = "block";

});


// ==================================================
// DISCOUNT CALCULATOR
// ==================================================

function calculateDiscount() {

    const original =
        Number(originalPrice.value);

    const discounted =
        Number(discountedPrice.value);


    if (
        !original ||
        original <= 0 ||
        discounted < 0 ||
        discounted >= original
    ) {

        discountPreview.textContent =
            "Discount: 0% OFF";

        return 0;
    }


    const discount =
        Math.round(
            ((original - discounted) / original) * 100
        );


    discountPreview.textContent =
        `Discount: ${discount}% OFF`;


    return discount;
}


originalPrice.addEventListener(
    "input",
    calculateDiscount
);

discountedPrice.addEventListener(
    "input",
    calculateDiscount
);


// ==================================================
// PREVIEW
// ==================================================

previewButton.addEventListener("click", () => {

    const selected =
        document.querySelector(
            'input[name="dealType"]:checked'
        );

    if (!selected) {

        alert("Please select a deal type.");

        return;
    }


    const type =
        selected.value;


    // ==================================================
    // GAME DEAL PREVIEW
    // ==================================================

    if (type === "game") {

        const name =
            document.getElementById(
                "gameName"
            ).value.trim();

        const platform =
            document.getElementById(
                "gamePlatform"
            ).value;

        const store =
            document.getElementById(
                "gameStore"
            ).value;

        const original =
            Number(
                originalPrice.value
            );

        const discounted =
            Number(
                discountedPrice.value
            );

        const description =
            document.getElementById(
                "gameDescription"
            )?.value.trim();

        const discount =
            calculateDiscount();


        if (!name) {

            alert(
                "Please enter the game name."
            );

            return;
        }


        if (!platform) {

            alert(
                "Please select a platform."
            );

            return;
        }


        if (!store) {

            alert(
                "Please select a store."
            );

            return;
        }


        if (
            !original ||
            original <= 0 ||
            discounted < 0 ||
            discounted >= original
        ) {

            alert(
                "Please enter valid prices."
            );

            return;
        }


        alert(

            `🎮 ${name}\n\n` +

            `Platform: ${platform}\n` +

            `Store: ${store}\n\n` +

            `Original Price: ₹${original}\n` +

            `Deal Price: ₹${discounted}\n` +

            `Discount: ${discount}% OFF\n\n` +

            `Description: ${
                description || "Not added"
            }`

        );

        return;
    }


    // ==================================================
    // STORE SALE PREVIEW
    // ==================================================

    const name =
        document.getElementById(
            "saleName"
        ).value.trim();

    const store =
        document.getElementById(
            "saleStore"
        ).value;

    const games =
        document.getElementById(
            "gamesOnSale"
        ).value.trim();

    const maxDiscount =
        document.getElementById(
            "maxDiscount"
        ).value;

    const description =
        document.getElementById(
            "saleDescription"
        )?.value.trim();


    if (!name) {

        alert(
            "Please enter the sale name."
        );

        return;
    }


    alert(

        `🏪 ${name}\n\n` +

        `Store: ${
            store || "Not selected"
        }\n` +

        `Games on Sale: ${
            games || "Not added"
        }\n` +

        `Maximum Discount: ${
            maxDiscount || 0
        }%\n\n` +

        `Description: ${
            description || "Not added"
        }`

    );

});


// ==================================================
// SAVE DEAL
// ==================================================

saveButton.addEventListener(
    "click",
    async () => {

        saveButton.disabled = true;

        saveButton.textContent =
            "Saving...";


        try {

            const selected =
                document.querySelector(
                    'input[name="dealType"]:checked'
                );


            if (!selected) {

                throw new Error(
                    "Please select a deal type."
                );

            }


            const type =
                selected.value;


            // ==================================================
            // COMMON INFORMATION
            // ==================================================

            const startDate =
                document.getElementById(
                    "startDate"
                ).value;

            const endDate =
                document.getElementById(
                    "endDate"
                ).value;

            const featured =
                document.getElementById(
                    "featured"
                ).checked;


            if (!startDate) {

                throw new Error(
                    "Please select the start date."
                );

            }


            if (!endDate) {

                throw new Error(
                    "Please select the end date."
                );

            }


            if (
                new Date(endDate) <
                new Date(startDate)
            ) {

                throw new Error(
                    "End date cannot be before start date."
                );

            }


            // ==================================================
            // COMMON SEO DATA
            // ==================================================

            const seoTitle =
                document.getElementById(
                    "seoTitle"
                )?.value.trim() || "";

            const seoDescription =
                document.getElementById(
                    "seoDescription"
                )?.value.trim() || "";

            const keywords =
                document.getElementById(
                    "seoKeywords"
                )?.value.trim() || "";


            // ==================================================
            // BASE DEAL OBJECT
            // ==================================================

            const deal = {

                type: type,

                startDate: startDate,

                endDate: endDate,

                featured: featured,

                seoTitle: seoTitle,

                seoDescription:
                    seoDescription,

                keywords: keywords,

                status: "active",

                createdAt:
                    serverTimestamp()

            };


            // ==================================================
            // GAME DEAL
            // ==================================================

            if (type === "game") {

                const name =
                    document.getElementById(
                        "gameName"
                    ).value.trim();

                const platform =
                    document.getElementById(
                        "gamePlatform"
                    ).value;

                const store =
                    document.getElementById(
                        "gameStore"
                    ).value;

                const original =
                    Number(
                        originalPrice.value
                    );

                const discounted =
                    Number(
                        discountedPrice.value
                    );

                const image =
                    document.getElementById(
                        "gameImage"
                    ).value.trim();

                const link =
                    document.getElementById(
                        "gameDealLink"
                    ).value.trim();


                // --------------------------------------------------
                // EXTRA GAME DETAILS
                // --------------------------------------------------

                const description =
                    document.getElementById(
                        "gameDescription"
                    )?.value.trim() || "";

                const genre =
                    document.getElementById(
                        "gameGenre"
                    )?.value.trim() || "";

                const developer =
                    document.getElementById(
                        "gameDeveloper"
                    )?.value.trim() || "";

                const publisher =
                    document.getElementById(
                        "gamePublisher"
                    )?.value.trim() || "";

                const releaseDate =
                    document.getElementById(
                        "gameReleaseDate"
                    )?.value || "";

                const edition =
                    document.getElementById(
                        "gameEdition"
                    )?.value.trim() || "";

                const region =
                    document.getElementById(
                        "gameRegion"
                    )?.value.trim() || "";

                const availability =
                    document.getElementById(
                        "gameAvailability"
                    )?.value.trim() || "";


                // --------------------------------------------------
                // VALIDATION
                // --------------------------------------------------

                if (!name) {

                    throw new Error(
                        "Please enter the game name."
                    );

                }


                if (!platform) {

                    throw new Error(
                        "Please select a platform."
                    );

                }


                if (!store) {

                    throw new Error(
                        "Please select a store."
                    );

                }


                if (
                    !original ||
                    original <= 0
                ) {

                    throw new Error(
                        "Please enter the original price."
                    );

                }


                if (
                    discounted < 0 ||
                    discounted >= original
                ) {

                    throw new Error(
                        "Discounted price must be lower than the original price."
                    );

                }


                const discount =
                    Math.round(
                        (
                            (original - discounted) /
                            original
                        ) * 100
                    );


                // --------------------------------------------------
                // SAVE GAME DEAL DATA
                // --------------------------------------------------

                deal.gameName =
                    name;

                deal.platform =
                    platform;

                deal.store =
                    store;

                deal.originalPrice =
                    original;

                deal.discountedPrice =
                    discounted;

                deal.discountPercent =
                    discount;

                deal.image =
                    image;

                deal.link =
                    link;

                deal.description =
                    description;

                deal.genre =
                    genre;

                deal.developer =
                    developer;

                deal.publisher =
                    publisher;

                deal.releaseDate =
                    releaseDate;

                deal.edition =
                    edition;

                deal.region =
                    region;

                deal.availability =
                    availability;

            }


            // ==================================================
            // STORE SALE
            // ==================================================

            else {

                const name =
                    document.getElementById(
                        "saleName"
                    ).value.trim();

                const store =
                    document.getElementById(
                        "saleStore"
                    ).value;

                const games =
                    document.getElementById(
                        "gamesOnSale"
                    ).value.trim();

                const maxDiscount =
                    Number(
                        document.getElementById(
                            "maxDiscount"
                        ).value
                    ) || 0;

                const image =
                    document.getElementById(
                        "saleImage"
                    ).value.trim();

                const description =
                    document.getElementById(
                        "saleDescription"
                    ).value.trim();

                const link =
                    document.getElementById(
                        "saleLink"
                    ).value.trim();


                // --------------------------------------------------
                // EXTRA SALE DETAILS
                // --------------------------------------------------

                const region =
                    document.getElementById(
                        "saleRegion"
                    )?.value.trim() || "";

                const saleCategory =
                    document.getElementById(
                        "saleCategory"
                    )?.value || "";

                const featuredGames =
                    document.getElementById(
                        "featuredGames"
                    )?.value.trim() || "";

                const terms =
                    document.getElementById(
                        "saleTerms"
                    )?.value.trim() || "";


                // --------------------------------------------------
                // VALIDATION
                // --------------------------------------------------

                if (!name) {

                    throw new Error(
                        "Please enter the sale name."
                    );

                }


                if (!store) {

                    throw new Error(
                        "Please select a store."
                    );

                }


                if (
                    maxDiscount < 0 ||
                    maxDiscount > 100
                ) {

                    throw new Error(
                        "Maximum discount must be between 0 and 100."
                    );

                }


                // --------------------------------------------------
                // SAVE STORE SALE DATA
                // --------------------------------------------------

                deal.saleName =
                    name;

                deal.store =
                    store;

                deal.gamesOnSale =
                    games;

                deal.maxDiscount =
                    maxDiscount;

                deal.image =
                    image;

                deal.description =
                    description;

                deal.link =
                    link;

                deal.region =
                    region;

                deal.saleCategory =
                    saleCategory;

                deal.featuredGames =
                    featuredGames;

                deal.terms =
                    terms;

            }


            // ==================================================
            // SAVE TO FIRESTORE
            // ==================================================

            await addDoc(
                collection(
                    db,
                    "deals"
                ),
                deal
            );


            // ==================================================
            // SUCCESS
            // ==================================================

            alert(
                "🔥 Deal saved successfully!"
            );


            window.location.reload();

        }


        catch (error) {

            console.error(
                "Deal save error:",
                error
            );


            alert(
                error.message ||
                "Failed to save deal."
            );


            saveButton.disabled =
                false;

            saveButton.textContent =
                "💰 Save Deal";

        }

    }
);