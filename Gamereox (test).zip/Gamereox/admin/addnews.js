import { db } from "../firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


console.log("ADDNEWS JS START");


async function saveNews(){

    try{


        const news = {

            title: document.getElementById("newsTitle").value.trim(),

            summary: document.getElementById("newsSummary").value.trim(),

            fullArticle: document.getElementById("fullArticle").value.trim(),

            image: document.getElementById("newsImage").value.trim(),

            youtube: document.getElementById("youtubeLink").value.trim(),

            category: document.getElementById("newsCategory").value,

            tags: document.getElementById("newsTags").value.trim(),

            relatedGame: document.getElementById("relatedGame").value.trim(),

            author: document.getElementById("author").value.trim(),

            publishDate: document.getElementById("publishDate").value,

            slug: document.getElementById("slug").value.trim(),

            status: document.getElementById("publishStatus").value,

            featured: document.getElementById("featuredNews").checked,

            breaking: document.getElementById("breakingNews").checked,

            editorsPick: document.getElementById("editorsPick").checked,

            seoTitle: document.getElementById("seoTitle").value.trim(),

            metaDescription: document.getElementById("metaDescription").value.trim(),

            canonicalUrl: document.getElementById("canonicalUrl").value.trim(),

            sourceName: document.getElementById("sourceName").value.trim(),

            sourceLink: document.getElementById("sourceLink").value.trim(),

            relatedArticles: document.getElementById("relatedArticles").value.trim(),

            createdAt: serverTimestamp(),

            updatedAt: serverTimestamp()

        };


        await addDoc(collection(db,"news"),news);


        alert("News saved successfully 📰");


    }
    catch(error){

        console.error(error);

        alert(error.message);

    }

}


const saveButton = document.getElementById("saveButton");

console.log("Button:", saveButton);

saveButton.addEventListener("click", saveNews);